# Lente

Primer prototipo funcional de la aplicación de estudio bíblico.

## Incluye

- Búsqueda local por referencia o tema.
- Análisis guiado: observar, contexto, palabras clave y preguntas.
- Guardados y reflexiones persistidos en el dispositivo.
- Cuaderno personal por pasaje y exportación de notas.
- Análisis de tipo de texto, referencias cruzadas y datos culturales de la época asistidos por IA.
- Comunidad simplificada para compartir reflexiones.
- Sección de planes: Gratis y Lente Plus (sin cobros activos).
- PWA instalable en Android desde el navegador.

## IA real

El servidor incluye `POST /api/ai` para consultar la Responses API de OpenAI sin exponer la clave en el navegador. Configurá `OPENAI_API_KEY` en el entorno donde se ejecute el servidor; si no existe, Lente continúa funcionando con el análisis local.

En PowerShell, antes de iniciar el servidor:

```powershell
$env:OPENAI_API_KEY="tu_clave"
node work/server.mjs
```

## Probar

Abrí `index.html` en un navegador. Para que el modo instalable y el cache funcionen completamente, serví la carpeta con cualquier servidor estático.

## Android

El proyecto ya incluye `manifest.json`, `service-worker.js` e ícono. En Chrome Android se puede elegir “Agregar a pantalla principal” para instalarlo como aplicación. La generación de APK nativa será el siguiente paso, usando este mismo frontend.
