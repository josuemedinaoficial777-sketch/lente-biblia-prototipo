# LENTE

MVP web de LENTE — Biblia · Contexto · Investigación · Comunidad.

## Publicar en Vercel

1. Entrá a Vercel y elegí **Add New → Project**.
2. Subí este proyecto como ZIP o conectalo a un repositorio Git.
3. No hace falta configurar build command.
4. Si Vercel pide framework, seleccioná **Other**.
5. Deploy.

## Estado del MVP

- Interfaz responsive.
- Navegación entre Inicio, Estudios, Comunidad, Recursos y Perfil.
- Estudios de ejemplo.
- Notas guardadas en el navegador mediante localStorage.
- Compartir estudio.
- Flujo de análisis: Texto, Contexto, Género, Recursos, Mundo del texto, Palabras, Referencias, Estructura y Preguntas.

## Próxima etapa

Para convertirlo en producto real: autenticación, base de datos, motor de IA, fuentes bíblicas/licencias, biblioteca de documentos, colaboración en tiempo real y panel administrativo.
