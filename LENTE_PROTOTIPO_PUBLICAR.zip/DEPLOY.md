# Publicar Lente

## Opción recomendada: Render

1. Crear un repositorio privado en GitHub y subir esta carpeta completa.
2. En Render elegir **New + > Web Service** y conectar el repositorio.
3. Usar:
   - Build command: dejar vacío
   - Start command: `node work/server.mjs`
   - Health check: `/health`
4. En **Environment** agregar `OPENAI_API_KEY` con la clave de la API. Nunca subirla a GitHub ni escribirla en `app.js`.
5. Desplegar. Render dará una dirección `https://...onrender.com` para compartir.

El archivo `render.yaml` ya contiene esta configuración como referencia. La clave de IA se configura como secreto del hosting, no en el navegador.

## Actualizaciones

Cada vez que se suban cambios al repositorio conectado, Render puede volver a publicar la aplicación en la misma dirección.
